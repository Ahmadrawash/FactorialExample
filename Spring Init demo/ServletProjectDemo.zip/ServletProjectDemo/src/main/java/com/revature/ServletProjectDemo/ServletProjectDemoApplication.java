package com.revature.ServletProjectDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServletProjectDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServletProjectDemoApplication.class, args);
	}

}
