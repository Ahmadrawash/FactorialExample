import React from "react";
import Navigation from "../NavBar";

export default function Test() {
  return (
    <>
      <Navigation />
      <div className="test-container">
        <h4>Welcome</h4>
        <h1>REVMAN3076</h1>
        <p>Account History</p>
      </div>
    </>
  );
}
