import "../css/App.css";

// The title component only has the logo/title and styling.
function Title() {
	return <h1 className="title">CacheMoney</h1>;
}

export default Title;
