// The NotFound component should be displayed if an invalid URL is entered
// ie. no defined route
function NotFoundView() {
	return <>404 not found!</>;
}

export default NotFoundView;
