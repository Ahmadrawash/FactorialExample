import React from "react";
import "./Quiz.css";

function Quiz(props) {
  return (
    <>
      <div className="quiz-container">
        <p>Something goes here</p>
      </div>
    </>
  );
}
