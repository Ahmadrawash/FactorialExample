public class Testing {
    public Testing()
    {
        MyTest mt = new MyTest();

    }
}
