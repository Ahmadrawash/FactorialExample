package Annotations;

public @interface Field {
}
