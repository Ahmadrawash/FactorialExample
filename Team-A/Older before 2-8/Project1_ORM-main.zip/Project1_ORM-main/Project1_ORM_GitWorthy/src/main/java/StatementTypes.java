//Enumeration holding the possible SQL statement types
//Basic CRUD operations only for now
public enum StatementTypes {
    CREATE,
    READ,
    UPDATE,
    DELETE
}
