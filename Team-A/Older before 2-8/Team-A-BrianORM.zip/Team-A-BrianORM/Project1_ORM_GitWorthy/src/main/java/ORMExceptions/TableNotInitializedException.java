package ORMExceptions;

public class TableNotInitializedException extends Exception {

}
